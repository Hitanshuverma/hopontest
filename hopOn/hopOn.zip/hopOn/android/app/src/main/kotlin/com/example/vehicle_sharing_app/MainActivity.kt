package com.example.vehicle_sharing_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
