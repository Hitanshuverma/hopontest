class DirectionDetails {
  int distanceValue;
  int durationValue;
  String distanceText;
  String durationText;
  String encodedPoints;

  DirectionDetails(
      {this.distanceText,
      this.distanceValue,
      this.durationText,
      this.durationValue,
      this.encodedPoints});
}
