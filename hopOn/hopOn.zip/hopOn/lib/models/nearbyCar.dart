class NearbyCar{
  String key;
  double longitude;
  double latitude;

  NearbyCar({
    this.key,
    this.longitude,
    this.latitude,
  });
}