import 'package:flutter/material.dart';

class AboutUs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Row(
          //   children: [
          //     CircleAvatar(
          //       radius: 60,
          //       foregroundColor: Colors.blue,
          //       backgroundImage: AssetImage(
          //         'images/ToyFaces_Colored_BG_47.jpg',
          //       ),
          //     ),
          //     Text(
          //       'Shivani Singh',
          //     ),
          //   ],
          // ),
        ],
      ),
    );
  }
}
