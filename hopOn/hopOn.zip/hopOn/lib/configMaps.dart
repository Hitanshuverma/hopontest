String apiKey = 'YOUR_ANDROID/iOS_APK_API_KEY';
String geocodingApi = 'YOUR_GEOCODING_API_KEY';
//(This geocoding api also works for places api and directions api if you have restricted the api key with these 3 services)
